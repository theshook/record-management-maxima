<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				
				<form action="<?php echo e(route('schedule.update', $schedule->id)); ?>" method="POST" id="updateStatus">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
					<input type="text" name="status" hidden id="status" value="">
					<span class="float-md-right mt-1 mr-1">
						<button type="submit" class="btn btn-success btn-sm" value="Add Later" id="addLater">
							Add Later
						</button>
					</span>
					<span class="float-md-right mt-1 mr-1">
						<button type="submit" class="btn btn-danger btn-sm" value="Disapprove" id="disapprove">
							Disapprove
						</button>
					</span>
					<span class="float-md-right mt-1 mr-1">
						<button type="submit" class="btn btn-primary btn-sm" value="Approve" id="approve">
							Approve
						</button>
					</span>
				</form>
				<h3 class="mb-0 text-uppercase">
					<span><img src="<?php echo e(asset('images/AssessmentLogoBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					<?php echo e($assessor->qualification->course); ?>

				</h3>
				<hr class="bg-primary">
			</div>
		</div>
		<div class="col-md-6">
			<h4>Assessor: <?php echo e($assessor->last_name. ', ' .$assessor->first_name. ' ' . $assessor->middle_name); ?></h4>
		</div>
		<div class="col-md-6">
			<h4>Schedule Date: <?php echo e($schedule->assessment_schedule); ?></h4>
		</div>

		
		<div class="col-md-12">
			<table class="table bg-white" id="student-list-table">
				<thead>
					<th>Name</th>
					<th>Reference #</th>
					<th>Applied for</th>
					<th></th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($applicant->last_name.', '.$applicant->first_name.' '.$applicant->middle_name); ?></td>
							<td><?php echo e($applicant->ref_no); ?></td>
							<td><?php echo e($applicant->assessment_type); ?></td>
							<td>
								<form action="<?php echo e(route('schedule.removestudents', $applicant->id)); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<?php echo method_field('PUT'); ?>
									<button submit class="btn btn-sm btn-danger">Delete</button>
								</form>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>

		
		<div class="col-sm-4">
			<form action="<?php echo e(route('schedule.search', [$schedule->id, $assessor->id])); ?>" method="POST" role="search">
				<?php echo e(csrf_field()); ?>

				<div class="input-group">
					<input type="text" class="form-control" name="q"
						placeholder="Search students"> <span class="input-group-btn">
						<button type="submit" class="btn btn-default">
							<span class="glyphicon glyphicon-search"></span>
						</button>
					</span>
				</div>
			</form>
		</div>
		<div class="col-md-12">
			<?php if(isset($applicants)): ?>
				<table class="table bg-white" id="student-list-table">
					<thead>
						<th>Name</th>
						<th>Reference #</th>
						<th>Applied for</th>
						<th></th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($applicant->last_name.', '.$applicant->first_name.' '.$applicant->middle_name); ?></td>
								<td><?php echo e($applicant->ref_no); ?></td>
								<td><?php echo e($applicant->assessment_type); ?></td>
								<td>
									<form action="<?php echo e(route('schedule.addstudents')); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<input type="hidden" value="<?php echo e($applicant->id); ?>" name="student_id">
										<input type="hidden" value="<?php echo e($assessor->id); ?>" name="assessor_id">
										<input type="hidden" value="<?php echo e($schedule->id); ?>" name="schedule_id">
										<button submit class="btn btn-sm btn-success">Add</button>
									</form>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<?php echo $applicants->render(); ?>

			<?php endif; ?>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
	$(document).ready(function() {
		$('#addLater').click(function(e) {
			e.preventDefault();
			$('#status').val('later');
			$('#updateStatus').submit();
		});
		$('#disapprove').click(function(e) {
			e.preventDefault();
			$('#status').val('not yet approved');
			$('#updateStatus').submit();
		});
		$('#approve').click(function(e) {
			e.preventDefault();
			$('#status').val('approved');
			$('#updateStatus').submit();
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/schedules/show.blade.php ENDPATH**/ ?>