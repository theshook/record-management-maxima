<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<h3 class="mb-0 text-uppercase">
					<span><img src="images/AdminBlue.png" style="width: 40px; text-align: center"></span>
					<?php echo e($assessor->qualification->course); ?>

				</h3>
				<hr class="bg-primary">
			</div>
		</div>
		<div class="col-md-6">
			<h4>Assessor: <?php echo e($assessor->last_name. ', ' .$assessor->first_name. ' ' . $assessor->middle_name); ?></h4>
		</div>
		<div class="col-md-6">
			<h4>Schedule Date: <?php echo e($schedule->assessment_schedule); ?></h4>
		</div>

		
		<div class="col-md-12">
			<table class="table bg-white" id="student-list-table">
				<thead>
					<th>Name</th>
					<th>Reference #</th>
					<th>Applied for</th>
				</thead>
				<tbody>
					<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($applicant->last_name.', '.$applicant->first_name.' '.$applicant->middle_name); ?></td>
							<td><?php echo e($applicant->ref_no); ?></td>
							<td><?php echo e($applicant->assessment_type); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/client/qualifications/show_list.blade.php ENDPATH**/ ?>