

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<ul class="list-group">
					<li class="list-group-item">
						<a href="<?php echo e(route('news.index')); ?>">Posts</a>
					</li>
					<li class="list-group-item">
						<a href="<?php echo e(route('categories.index')); ?>">Categories</a>
					</li>
				</ul>
			</div>
			<div class="col-md-8">
				<div class="card">
					<div class="card-header">
						<strong>News</strong>
						<a href="<?php echo e(route('news.create')); ?>" class="btn btn-success btn-sm float-md-right">
							Add News
						</a>
					</div>
					<div class="card-body">
						<?php if($news->count() > 0): ?>
							<table class="table">
								<thead>
									<th>Title</th>
									<th>Category</th>
									<th class="text-right">Date Create</th>
								</thead>
								<tbody>
									<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td>
												<a href="<?php echo e(route('news.show', $new->id)); ?>"><?php echo e($new->title); ?></a>
											</td>
											<td>
												<a href="<?php echo e(route('categories.edit', $new->category->id)); ?>">
													<?php echo e($new->category->name); ?>

												</a>
											</td>
											<td class="text-right">
												<?php echo e($new->created_at); ?>

											</td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						<?php else: ?>
							<h3 class="text-center">No news yet</h3>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/home.blade.php ENDPATH**/ ?>