<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<span class="float-md-right mt-1">
                    <form action="<?php echo e(route('multiple.print')); ?>" method="GET" id="formSave">
                    <?php echo csrf_field(); ?>
						<button type="submit" class="btn btn-primary btn-sm" id="fetchSave">PRINT SELECTED</button>
					</form>
				</span>
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/CourseRegisteredBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					PRINT CERTIFICATE
				</h3>
				<hr class="bg-primary">
            </div>
            <form action="<?php echo e(route('print_certificate_search')); ?>" method="POST" role="search" class="p-3 bg-primary">
                <?php echo e(csrf_field()); ?>

                <div class="input-group w-50">
                    <input type="text" class="form-control" name="q"
                        placeholder="Search Names or Tracking Number"> 
                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-secondary">
                            Go
                        </button>
                    </span>
                </div>
            </form>
            <table class="table bg-white">
                    <thead>
                        <th></th>
                        <th>Name</th>
                        <th>Qualification</th>
                        <th>Ref #</th>
                        <th>Date Requested</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="certificate_ids[]" value="<?php echo e($fb->id); ?>">
                                </td>
                                <td>
                                    <?php echo e($fb->fullname); ?>

                                </td>
                                <td>
                                    <?php echo e($fb->qualification->course); ?>

                                </td>
                                <td>
                                    <?php echo e($fb->reference_number); ?>

                                </td>
                                <td>
                                    <?php echo e($fb->created_at); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('cert.show', $fb->id)); ?>" class="btn btn-success btn-sm">PREVIEW</a>
                                    <a href="<?php echo e(route('cert.print', $fb->id)); ?>" target="_blank"
                                  class="btn btn-primary btn-sm">PRINT</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h3 class="text-center"> No students as of now.</h3>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo $students->render(); ?>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(){
        $("#fetchSave").click(function(e) {
            e.preventDefault()
            var val = [];
            $(':checkbox:checked').each(function(i){
            val[i] = $(this).val();
            });
            var input = $("<input>")
               .attr("type", "hidden")
               .attr("name", "mydata").val(val);
            $("#formSave").append(input);
            $("#formSave").submit();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/certificate/print_certificate_index.blade.php ENDPATH**/ ?>