<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<span class="float-md-right mt-1">
					<a href="<?php echo e(route('student.create')); ?>" class="btn btn-primary btn-sm">
						ADD NEW STUDENT
					</a>
				</span>
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/AdminBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					STUDENT PROFILE
				</h3>
				<hr class="bg-primary">
			</div>
			<form action="<?php echo e(route('student.search')); ?>" method="POST" role="search" class="p-3 bg-primary">
				<?php echo e(csrf_field()); ?>

				<div class="input-group w-50">
					<input type="text" class="form-control" name="q"
						placeholder="Search Names or email"> 
						
					<span class="input-group-btn">
						<button type="submit" class="btn btn-default">
							<span class="glyphicon glyphicon-search"></span>
						</button>
					</span>
				</div>
			</form>
			<table class="table bg-white">
				<thead>
					<th>Name</th>
					<th>Qualification</th>
					<th>Mobile</th>
					<th>Email</th>
					<th></th>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td>
								<?php echo e($fb->last_name.', '.$fb->first_name.' '.$fb->name_extension.' '.$fb->middle_name); ?>

							</td>
							<td>
								<?php echo e($fb->qualification->course); ?>

							</td>
							<td>
								<?php echo e($fb->mobile); ?>

							</td>
							<td>
								<?php echo e($fb->email); ?>

							</td>
							<td>
								<form action="<?php echo e(route('student.destroy', $fb->id)); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<?php echo method_field('DELETE'); ?>
									<a href="<?php echo e(route('student.edit', $fb->id)); ?>" class="btn btn-primary btn-sm">
										View
									</a>
									<button type="submit" class="btn btn-danger btn-sm">Delete</button>
								</form>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<h3 class="text-center"> No students as of now.</h3>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo $students->render(); ?>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/student/index.blade.php ENDPATH**/ ?>