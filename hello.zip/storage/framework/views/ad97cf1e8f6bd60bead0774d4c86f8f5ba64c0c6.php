<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<span class="float-md-right mt-1">
					<a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-sm">
						ADD NEW ADMIN
					</a>
				</span>
				<h3 class="mb-0">
					<span><img src="images/AdminBlue.png" style="width: 40px; text-align: center"></span>
					ADMIN PROFILE
				</h3>
				<hr class="bg-primary">
			</div>
			<div class="">
				<form action="<?php echo e(route('users.search')); ?>" method="POST" role="search" class="p-3 bg-primary">
					<?php echo e(csrf_field()); ?>

					<div class="input-group w-50">
						<input type="text" class="form-control" name="q"
							placeholder="Search Names or Email"> 
							
						<span class="input-group-btn">
							<button type="submit" class="btn btn-default">
								<span class="glyphicon glyphicon-search"></span>
							</button>
						</span>
					</div>
				</form>
			</div>
			<table class="table bg-white">
				<thead>
					<th>Name</th>
					<th>Position</th>
					<th>Email</th>
					<th>Contact</th>
					<th></th>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($fb->last_name.', '.$fb->first_name.' '.$fb->name_extension.' '.$fb->middle_name); ?>

							</td>
							<td><?php echo e($fb->position); ?></td>
							<td><?php echo e($fb->email); ?></td>
							<td><?php echo e($fb->mobile); ?></td>
							<td>
								<form action="<?php echo e(route('users.destroy', $fb->id)); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<a href="<?php echo e(route('users.show', $fb->id)); ?>" class="btn btn-primary btn-sm">View</a>
								<button type="submit" class="btn btn-danger btn-sm">Delete</button>
								</form>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<h3 class="text-center"> No users as of now.</h3>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo $users->render(); ?>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\maxima\resources\views/users/index.blade.php ENDPATH**/ ?>