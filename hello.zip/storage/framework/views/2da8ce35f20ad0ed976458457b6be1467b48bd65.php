<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item">
                    <a href="<?php echo e(route('news.index')); ?>">Posts</a>
                </li>
                <li class="list-group-item">
                    <a href="/categories">Categories</a>
                </li>
            </ul>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
					<strong>Create News</strong>
					<a href="<?php echo e(route('news.index')); ?>" class="btn btn-warning float-md-right text-white">
						Back
					</a>
				</div>
                <div class="card-body">
                    <form action="<?php echo e(route('news.store')); ?>" 
                    method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
						<div class="form-group">
                            <input type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" placeholder="Title" value="<?php echo e(old('title')); ?>">

                            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>

						<div class="form-group">
							<textarea name="description" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="4" cols="50"placeholder="Description"><?php echo e(old('description')); ?></textarea>

							<?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
								<span class="invalid-feedback" role="alert">
									<strong><?php echo e($message); ?></strong>
								</span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>

						<div class="form-group">
							<select name="category_id" id="category_id" class="form-control">
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<div class="form-group">
							<div class="input-group mb-3">
								<div class="custom-file">
									<input type="file" accept="image/x-png,image/gif,image/jpeg" class="custom-file-input" id="image" aria-describedby="inputGroupFileAddon01" name="image">
									<label class="custom-file-label" for="image">
										Choose image...
									</label>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<img src="" id="blah" alt="" class="img-fluid" width="300px">
						</div>

						<div class="form-group">
							<button type="submit" class="btn btn-success">
								Add News
                            </button>
						</div>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/loadImageOnUpload.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/news/create.blade.php ENDPATH**/ ?>