<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-primary">
                    <h3 class="mb-0">
                        <span><img src="<?php echo e(asset('images/AssessmentLogo.png')); ?>" style="width: 25px; text-align: center"></span>
                        ASSESSMENT SCHEDULE
                    </h3>
                    <hr class="bg-primary">
                </div>
                <table class="table bg-white">
                    <thead>
                        <th>Sector</th>
                        <th>Qualification</th>
                        <th>Accreditation #</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($qualification->sector); ?></td>
                                <td><?php echo e($qualification->course); ?></td>
                                <td class="text-danger"><?php echo e($qualification->accreditation); ?></td>
                                <td>
                                    <a href="<?php echo e(route('qualifications.show', $qualification->id)); ?>" class="btn btn-primary btn-sm">Schedule</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo $qualifications->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\maxima\resources\views/client/qualifications/index.blade.php ENDPATH**/ ?>