<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <div class="card-header">
                        <h4>
                            <?php echo e($new->title); ?>

                        </h4>
                        <span class="text-secondary text-small">
                            <?php echo e(date('F d, Y', strtotime($new->updated_at))); ?>

                        </span>
                        <span class="float-md-right text-small text-secondary">
                            Category: <?php echo e($new->category->name); ?>

                        </span>
                    </div>
                    <div class="card-body">
                            <p><?php echo e($new->description); ?></p>
                            <img src="<?php echo e(asset('storage/'.$new->image)); ?>" alt="<?php echo e($new->title); ?>" class="img-fluid" height="300px" width="300px">
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\maxima\resources\views/welcome.blade.php ENDPATH**/ ?>