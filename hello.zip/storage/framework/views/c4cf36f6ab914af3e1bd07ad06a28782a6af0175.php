<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row justify-content-center">
        <div class="col-xs-12">
			<div class="text-primary">
				
				<h3 class="mb-0">
					<span><img src="images/AdminBlue.png" style="width: 40px; text-align: center"></span>
					PRINT APPLICATION FORM
				</h3>
				<hr class="bg-primary">

				<form action="<?php echo e(route('applicants.search')); ?>" method="POST" role="search" class="p-3 bg-primary">
					<?php echo e(csrf_field()); ?>

					<div class="input-group w-50">
						<input type="text" class="form-control" name="q"
							placeholder="Search Names or Tracking Number"> 
							
						<span class="input-group-btn">
							<button type="submit" class="btn btn-default">
								<span class="glyphicon glyphicon-search"></span>
							</button>
						</span>
					</div>
				</form>
				<table class="table bg-white">
					<thead>
						<th>Name</th>
						<th>Qualification</th>
						<th>Reference #</th>
						<th>Date Registered</th>
						<th></th>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td>
									<?php echo e($app->last_name.', '.$app->first_name.' '.$app->name_extension.' '.$app->middle_name); ?>

								</td>
								<td>
									<?php echo e($app->qualification->course); ?>

								</td>
								<td>
									<?php echo e($app->ref_no); ?>

								</td>
								<td>
									<?php echo e($app->created_at); ?>

								</td>
								<td>
									<a href="<?php echo e(route('applicants.show', $app->id)); ?>" class="btn btn-success btn-sm">Preview</a>
									<a href="<?php echo e(route('applicants.print', $app->id)); ?>"  target="_blank" class="btn btn-primary btn-sm">Print</a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<h4>No verified applicants as of now</h4>
						<?php endif; ?>
					</tbody>
				</table>
				<?php echo $applicants->render(); ?>

			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\maxima\resources\views/applicant/index.blade.php ENDPATH**/ ?>