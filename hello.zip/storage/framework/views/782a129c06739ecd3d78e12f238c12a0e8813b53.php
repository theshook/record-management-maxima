<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item">
                    <a href="<?php echo e(route('news.index')); ?>">Posts</a>
                </li>
                <li class="list-group-item">
                    <a href="/categories">Categories</a>
                </li>
            </ul>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
					<strong><?php echo e(isset($category) ? 'Edit Category' : 'Create Category'); ?></strong>
					<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-warning float-md-right text-white">
						Back
					</a>
				</div>
                <div class="card-body">
                    <form action="<?php echo e(isset($category) ? 
                    route('categories.update', $category->id) : 
                    route('categories.store')); ?>" 
                    method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($category)): ?>
                            <?php echo method_field('PUT'); ?>
                        <?php endif; ?>
						<div class="form-group">
                            <input type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" placeholder="Category Name" value="<?php echo e(isset($category) ? $category->name : old('name')); ?>">

                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-success">
                                <?php echo e(isset($category) ? 'Update Category' : 'Add Category'); ?>

                            </button>
						</div>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/categories/create.blade.php ENDPATH**/ ?>