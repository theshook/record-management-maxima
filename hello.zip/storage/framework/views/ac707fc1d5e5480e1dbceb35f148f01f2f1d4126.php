<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-primary">
                    <h3 class="mb-0">
                        <span><img src="<?php echo e(asset('images/AssessmentLogo.png')); ?>" style="width: 25px; text-align: center"></span>
                        <?php echo e($print->qualification->course); ?> Core Competencies
                    </h3>
                    <hr class="bg-primary">
				</div>
				<form action="<?php echo e(route('coc.update', $print->id)); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
					<div class="form-group row">
						<div class="col-sm-3">
                            <input type="text" class="form-control <?php if ($errors->has('code_no')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code_no'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Code No" name="code_no" value="<?php echo e($print->code_no); ?>">
                            <?php if ($errors->has('code_no')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('code_no'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<div class="col-sm-7">
                            <input type="text" class="form-control <?php if ($errors->has('core_competencies')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('core_competencies'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Core Competencies" name="core_competencies" value="<?php echo e($print->core_competencies); ?>">
                            <?php if ($errors->has('core_competencies')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('core_competencies'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
						<input type="text" class="form-control" placeholder="Code No" name="qualification_id" value="<?php echo e($print->qualification->id); ?>" hidden>
						<div class="col-sm-2">
							<button type="submit" class="btn btn-success btn-sm" >Update</button>
						</div>
					</div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\maxima\resources\views/print/cocEdit.blade.php ENDPATH**/ ?>