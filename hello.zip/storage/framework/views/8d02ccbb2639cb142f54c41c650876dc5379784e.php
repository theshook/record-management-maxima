<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/AssessmentLogoBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					CREATE SCHEDULE
				</h3>
				<hr class="bg-primary">

				<form action="<?php echo e(route('schedule.store')); ?>" method="POST">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<select name="assessor_id" class="form-control">
							<?php $__currentLoopData = $assessors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($assessor->id); ?>"><?php echo e($assessor->last_name.', '.$assessor->first_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div class="form-group">
						<input type="date" class="form-control" name="assessment_schedule">
					</div>

					<button type="submit" class="btn btn-success btn-sm pl-3 pr-3">Submit</button>
				</form>
			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/schedules/create.blade.php ENDPATH**/ ?>