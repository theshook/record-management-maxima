<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
                <span class="float-md-right mt-1">
                    <a href="<?php echo e(route('verification.index')); ?>" class="btn btn-warning btn-sm pl-5 pr-5 text-white">
                        BACK
                    </a>
                </span>
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/FeedbackBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					VERIFICATION REQUEST
				</h3>
				<hr class="bg-primary">
			</div>
			<div class="card w-75 mx-auto bg-light shadow-lg">
                <div class="card-body">
                    <form action="<?php echo e(route('verification.update', $verification->id )); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <span class="float-md-right m-3">
                            <button type="submit" class="btn btn-info btn-sm pl-5 pr-5 text-white">Verified!</button>
                        </span>
                    </form>
                    <div class="pl-5 pb-5">
                        <h4>Name of Sender: 
                            <span class="text-primary">
                                <?php echo e($verification->fullname); ?>

                            </span>
                        </h4>
                        <h4>Reference/Tracking Number: 
                            <span class="text-danger">
                                <?php echo e($verification->tracking_number); ?>

                            </span>
                        </h4>
                        <img src="<?php echo e($verification->image); ?>" alt="<?php echo e($verification->fullname); ?>" class="img-fluid">
                        <h6 class="float-md-right text-secondary">
                            <em>
                                Contact #: <?php echo e($verification->contact); ?>

                                <br>
                                Email: <?php echo e($verification->email); ?>

                            </em>
                        </h6>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/verification/show.blade.php ENDPATH**/ ?>