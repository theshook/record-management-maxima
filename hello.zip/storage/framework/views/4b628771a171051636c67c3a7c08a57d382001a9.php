<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/FeedbackBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					VERIFICATIONS REQUEST
				</h3>
				<hr class="bg-primary">
			</div>
			<div class="">
				<form action="<?php echo e(route('verification.search')); ?>" method="POST" role="search" class="p-3 bg-primary">
					<?php echo e(csrf_field()); ?>

					<div class="input-group w-50">
						<input type="text" class="form-control" name="q"
							placeholder="Search Names or Tracking Number"> 
							
						<span class="input-group-btn">
							<button type="submit" class="btn btn-default">
								<span class="glyphicon glyphicon-search"></span>
							</button>
						</span>
					</div>
				</form>
			</div>
			<table class="table bg-white">
				<thead>
					<th>Name of Sender</th>
					<th width="40%">Reference No</th>
					<th>Date Received</th>
					<th>Receipt Image</th>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $verifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr class="<?php echo e($fb->verified == 1 ? 'text-white bg-info' : ''); ?>">
							<td>
								<?php echo e($fb->verified == 1 ? '♥' : ''); ?>

								<?php echo e($fb->fullname); ?>

							</td>
							<td><?php echo e($fb->tracking_number); ?></td>
							<td><?php echo e($fb->created_at); ?></td>
							<td><a href="<?php echo e(route('verification.show', $fb->id)); ?>" class="btn btn-primary btn-sm">View</a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<h3 class="text-center"> No verifications as of now.</h3>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo $verifications->render(); ?>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/verification/index.blade.php ENDPATH**/ ?>