<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-primary">
                    <span class="float-md-right mt-1">
                        <a href="<?php echo e(route('qualifications.index')); ?>" class="btn btn-warning btn-sm text-white pl-5 pr-5">
                            Back
                        </a>
                    </span>
                    <h3 class="mb-0">
                        <span><img src="<?php echo e(asset('images/AssessmentLogoBlue.png')); ?>" style="width: 25px; text-align: center"></span>
                        ASSESSMENT SCHEDULE
                    </h3>
                    <hr class="bg-primary">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mx-auto">
                <div class="card">
                    <div class="card-header text-primary text-center">
                        <h4><?php echo e(isset($qualification) ? 'EDIT' : 'ADD NEW'); ?> QUALIFICATION</h4>
                    </div>
                    <div class="card-body">
                        <form 
                        action="<?php echo e(isset($qualification) ? route('qualifications.update', $qualification->id) : route('qualifications.store')); ?>" 
                        method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if(isset($qualification)): ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                            <div class="form-group">
                                <input 
                                type="text" 
                                class="form-control <?php if ($errors->has('sector')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sector'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                name="sector" 
                                placeholder="Sector" 
                                value="<?php echo e(isset($qualification) ? $qualification->sector : old('sector')); ?>" 
                                autofocus>

                                <?php if ($errors->has('sector')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sector'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <input 
                                type="text" 
                                class="form-control <?php if ($errors->has('course')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('course'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                                name="course" 
                                placeholder="Qualification" 
                                value="<?php echo e(isset($qualification) ? $qualification->course : old('course')); ?>">

                                <?php if ($errors->has('course')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('course'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <input 
                                type="text" 
                                class="form-control <?php if ($errors->has('accreditation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('accreditation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="accreditation" 
                                placeholder="Accreditation #" 
                                value="<?php echo e(isset($qualification) ? $qualification->accreditation : old('accreditation')); ?>">

                                <?php if ($errors->has('accreditation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('accreditation'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <textarea 
                                name="description" 
                                id="description" 
                                class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Description..." 
                                cols="30" 
                                rows="5"><?php echo e(isset($qualification) ? $qualification->description : old('description')); ?></textarea>
                                
                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-small">
                                    <?php echo e(isset($qualification) ? 'Update' : 'Add'); ?> Qualification
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/qualifications/create.blade.php ENDPATH**/ ?>