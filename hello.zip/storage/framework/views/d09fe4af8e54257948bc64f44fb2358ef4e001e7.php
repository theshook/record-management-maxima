<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
                <span class="float-md-right mt-1">
                    <a href="<?php echo e(route('feedback.index')); ?>" class="btn btn-warning btn-sm pl-5 pr-5 text-white">
                        BACK
                    </a>
                </span>
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/FeedbackBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					FEED BACK AND CONCERNS
				</h3>
				<hr class="bg-primary">
			</div>
			<div class="card w-75 mx-auto bg-light shadow-lg">
                <div class="row p-5">
                    <div class="col-md-4">
                        <h4>Name of Sender: </h4>
                        <h4>Message: </h4>
                    </div>
                    <div class="col-md-8">
                        <h4>
                            <span class="text-primary">
                                <?php echo e($feedback->fullname); ?>

                            </span>
                        </h4>
                        <h5>
                            <span class="text-black">
                                <?php echo e($feedback->message); ?>

                            </span>
                        </h5>
                        <h6 class="float-md-right text-secondary">
                            <em>
                                <?php echo e($feedback->created_at); ?>

                                <br>
                                <?php echo e($feedback->email); ?>

                            </em>
                        </h6>
                    </div>
                </div>
            </div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/feedback/show.blade.php ENDPATH**/ ?>