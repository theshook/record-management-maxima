<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/AdminBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					<?php echo e(isset($assessor) ? 'EDIT ASSESSOR' : 'ADD NEW ASSESSOR'); ?>

				</h3>
				<hr class="bg-primary">
			</div>

			<div class="form-group">
				<h5 class="text-white bg-primary p-2">1. FIELD INFORMATION</h5>
			</div>
    
			<form action="<?php echo e(isset($assessor) ? route('assessor.update', $assessor->id) : route('assessor.store')); ?>"
			 method="POST">
				<?php echo csrf_field(); ?>
				<?php if(isset($assessor)): ?> 
				<?php echo method_field('PUT'); ?>
				<?php endif; ?>
				<div class="form-group row">
					<label for="training_center" class="col-md-4 col-form-label text-primary">
						QUALIFICATION ACCREDITED:
					</label>
					<div class="col-md-4">
						<select class="form-control" data-val="true" data-val-text="The qualification must be text." data-val-required="Please select Qualification" id="Qualification" name="qualification_id">
							<?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($qualification->id); ?>" 
								<?php if(isset($assessor)): ?>
									<?php echo e($assessor->qualification_id == $qualification->id ? 'selected' : ''); ?>

								<?php endif; ?>
								><?php echo e($qualification->course); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
    
				<hr class="bg-primary">
    
				<div class="form-group">
					<h5 class="text-white bg-primary p-2">2. PERSONAL PROFILE</h5>
				</div>
    
				<div class="form-group row">
					<label for="last_name" class="col-md-4 col-form-label text-primary">
						SURNAME:
					</label>
					<div class="col-md-8">
						<input type="text" id="last_name" class="form-control <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="last_name" placeholder="SURNAME" 
						value="<?php echo e(isset($assessor) ? $assessor->last_name : old('last_name')); ?>">

						<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>
    
				<div class="form-group row">
					<label for="first_name" class="col-md-4 col-form-label text-primary">
						FIRST NAME:
					</label>
					<div class="col-md-8">
						<input type="text" id="first_name" class="form-control  <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="first_name" placeholder="FIRST NAME"
						value="<?php echo e(isset($assessor) ? $assessor->first_name : old('first_name')); ?>">

						<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>
    
				<div class="form-group row">
					<label for="middle_name" class="col-md-4 col-form-label text-primary">
						MIDDLE NAME:
					</label>
					<div class="col-md-4">
						<input type="text" id="middle_name" class="form-control  <?php if ($errors->has('middle_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('middle_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="middle_name" placeholder="MIDDLE NAME"
						value="<?php echo e(isset($assessor) ? $assessor->middle_name : old('middle_name')); ?>">

						<?php if ($errors->has('middle_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('middle_name'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>

					<label for="name_extension" class="col-md-2 col-form-label text-primary">
						NAME EXTENSION:
					</label>
					<div class="col-md-2">
						<input type="text" id="name_extension" class="form-control <?php if ($errors->has('name_extension')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name_extension'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name_extension" placeholder="NAME EXTENSION"
						value="<?php echo e(isset($assessor) ? $assessor->name_extension : old('name_extension')); ?>">

						<?php if ($errors->has('name_extension')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name_extension'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>
    
				<div class="form-group row">
					<label for="acnumber" class="col-md-4 col-form-label text-primary">
						ACCREDITATION NUMBER:
					</label>
					<div class="col-md-4">
						<input type="text" id="acnumber" class="form-control <?php if ($errors->has('accreditation_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('accreditation_number'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="accreditation_number" placeholder="Accreditation Number"
						value="<?php echo e(isset($assessor) ? $assessor->accreditation_number : old('accreditation_number')); ?>">

						<?php if ($errors->has('accreditation_number')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('accreditation_number'); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
				</div>

				<hr class="bg-primary">

				<button type="submit" class="btn btn-success btn-xl pr-5 pl-5">Submit</button>
				<button type="reset" class="btn btn-danger btn-xl pr-5 pl-5">Reset</button>
			</form>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/assessor/create.blade.php ENDPATH**/ ?>