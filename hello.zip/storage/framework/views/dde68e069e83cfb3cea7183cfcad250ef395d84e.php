
<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<span class="float-md-right mt-1">
					<button class="btn btn-success btn-sm" id="clickMe" >Print This</button>
				</span>
				
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/CourseRegisteredBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					PRINT CERTIFICATE
				</h3>
				<hr class="bg-primary">
			</div>
			<div id="printThis">
				<?php $__currentLoopData = $requestCertificate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="card img-fluid">
						<img class="card-img-top" src="<?php echo e(asset('images/blankcertificate.jpg')); ?>" alt="Card image" style="width:100%">
						<div class="card-img-overlay">
							<h1 class="text-underlined text-uppercase font-weight-bold text-center " style="margin-top: 220px; font-face:'Arial Black';">
								<u><?php echo e(strtoupper($item->fullname)); ?></u>
							</h1>
							<h2 class="text-underlined text-uppercase font-weight-bold text-center " style="margin-top: 25px;">
								<?php echo e(strtoupper($item->qualification->course)); ?>

							</h2>
							<div class=" font-weight-bolder" style="height: 380px;">
								<table align="center">
									<tr>
										<td style="font-size:12px;"">
											<strong>CODE NO.</strong>
										</td>
										<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td style="font-size:12px;"">
											<strong>CODE COMPETENCIES</strong>
										</td>
									</tr>
									<?php $__currentLoopData = $item->qualification->printCertificateModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td style="font-size:12px;"><strong><?php echo e($item1-> code_no); ?></strong></td>
											<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
											<td style="font-size:12px;"><strong><?php echo e($item1-> core_competencies); ?></strong></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
								<div class="mx-auto text-center w-75 mt-2">
									<h5>
										<?php
											$dt = new DateTime();
											$dt->setTimezone(new DateTimeZone('Asia/Manila'));
										?>
										<strong>
											<em>
												Conducted on <?php echo e(date('F d, Y', strtotime($item->created_at))); ?>

													to <?php echo e(\Carbon\Carbon::now('+08:00')->format('F d, Y')); ?> at Maxima Technical Skills Training Institute, Inc. Given this <?php echo e(\Carbon\Carbon::now('+08:00')->format('jS')); ?> day of <?php echo e(\Carbon\Carbon::now('+08:00')->format('F Y')); ?> at Dagupan City, Pangasinan
											</em>
										</strong> 
									</h5>
								</div>
							</div>
							<h4 class="text-center">
								<?php
									$words = explode(" ", $item->qualification->course);
									$acronym = "";
		
									foreach ($words as $w) {
									$acronym .= $w[0];
									}
									$input = $item->id;
									$number = str_pad($input, 3, "0", STR_PAD_LEFT);
								?>
								Certificate No. <?php echo e($acronym.\Carbon\Carbon::now('+08:00')->format('Y').$number); ?>

							</h4>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
				$(document).ready(function() {
			$("#clickMe").click(function() {
				$("#printThis").print({
					globalStyles: false,
					mediaPrint: true,
					stylesheet: '<?php echo asset('css/certificate.css'); ?>',
					noPrintSelector: ".no-print",
					iframe: false,
					append: null,
					prepend: null,
					manuallyCopyFormValues: true,
					deferred: $.Deferred(),
					timeout: 750,
					title: null,
					doctype: '<!doctype html>'
				});
			})
		});
		var reference = (function thename(){

			$("#printThis").print({
					globalStyles: false,
					mediaPrint: true,
					stylesheet: '<?php echo asset('css/certificate.css'); ?>',
					noPrintSelector: ".no-print",
					iframe: false,
					append: null,
					prepend: null,
					manuallyCopyFormValues: true,
					deferred: $.Deferred(),
					timeout: 750,
					title: null,
					doctype: '<!doctype html>'
				});

return thename; //return the function itself to reference

}()); //auto-run

$(document).ready(function() {
$("#clickMe").click(function() {
	$("#printThis").print({
					globalStyles: false,
					mediaPrint: true,
					stylesheet: '<?php echo asset('css/certificate.css'); ?>',
					noPrintSelector: ".no-print",
					iframe: false,
					append: null,
					prepend: null,
					manuallyCopyFormValues: true,
					deferred: $.Deferred(),
					timeout: 750,
					title: null,
					doctype: '<!doctype html>'
				});
})
});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/certificate/multiple.blade.php ENDPATH**/ ?>