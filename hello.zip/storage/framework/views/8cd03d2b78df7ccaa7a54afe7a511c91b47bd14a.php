<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-primary">
                    <h3 class="mb-0 text-uppercase">
                        <span><img src="<?php echo e(asset('images/AssessmentLogoBlue.png')); ?>" style="width: 25px; text-align: center"></span>
                        <?php echo e($qualification->course); ?>

                    </h3>
                    <hr class="bg-primary">
                </div>
                <table class="table bg-white">
                    <thead>
                        <th>Assessor</th>
                        <th>Date of Assessment</th>
                        <th>Status</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $qualification->assessors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $qa->schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sched): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($qa->last_name.', '. $qa->first_name); ?></td>
                                <td><?php echo e($sched->assessment_schedule); ?></td>
                                <td class="text-danger"><?php echo e($sched->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('schedule.showList', [$sched->id, $qa->id])); ?>" class="btn btn-primary btn-sm">List</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appClient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/client/qualifications/show.blade.php ENDPATH**/ ?>