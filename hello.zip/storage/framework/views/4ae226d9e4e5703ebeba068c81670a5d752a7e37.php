
<?php $__env->startSection('content'); ?>
<div class="container">    
    <div class="row">
        <div class="col-md-12">
			<div class="text-primary">
				<h3 class="mb-0">
					<span><img src="<?php echo e(asset('images/CourseRegisteredBlue.png')); ?>" style="width: 40px; text-align: center"></span>
					CERTIFICATE STATUS
				</h3>
				<hr class="bg-primary">
			</div>
			<form action="<?php echo e(route('certificate.status.search')); ?>" method="POST" role="search" class="p-3 bg-primary">
				<?php echo e(csrf_field()); ?>

				<div class="input-group w-50">
					<input type="text" class="form-control" name="q"
						placeholder="Search Names or Reference #"> 
						
					<span class="input-group-btn">
						<button type="submit" class="btn btn-default">
							<span class="glyphicon glyphicon-search"></span>
						</button>
					</span>
				</div>
			</form>
			<table class="table bg-white">
				<thead>
					<th>Name</th>
					<th>Qualification</th>
					<th>Ref #</th>
					<th>Date Requested</th>
					<th>Date Printed</th>
					<th></th>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td>
								<?php echo e($fb->fullname); ?>

							</td>
							<td>
								<?php echo e($fb->qualification->course); ?>

							</td>
							<td>
								<?php echo e($fb->reference_number); ?>

							</td>
							<td>
								<?php echo e($fb->created_at); ?>

							</td>
							<td>
								<span  class="<?php echo e($fb->isPrinted == 0 ? 'text-danger' : ''); ?>">
									<?php echo e($fb->isPrinted == 0 ? 'not yet printed' : $fb->updated_at); ?>

								</span>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<h3 class="text-center"> No students as of now.</h3>
					<?php endif; ?>
				</tbody>
			</table>
			<?php echo $students->render(); ?>

		</div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/print/student.blade.php ENDPATH**/ ?>