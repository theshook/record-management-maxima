
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-primary">
                    <span class="float-md-right mt-1">
                        <a href="<?php echo e(route('qualifications.create')); ?>" class="btn btn-primary btn-sm">
                            Add Qualification
                        </a>
                    </span>
                    <h3 class="mb-0">
                        <span><img src="<?php echo e(asset('images/CourseRegisteredBlue.png')); ?>" style="width: 25px; text-align: center"></span>
                        SETUP CERTIFICATE
                    </h3>
                    <hr class="bg-primary">
                </div>
                <table class="table bg-white display table-striped" id="myTable">
                    <thead>
                        <th>Sector</th>
                        <th>Qualification</th>
                        <th>Accreditation #</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qualification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($qualification->sector); ?></td>
                                <td><?php echo e($qualification->course); ?></td>
                                <td class="text-danger"><?php echo e($qualification->accreditation); ?></td>
                                <td>
                                    <a href="<?php echo e(route('add.coc', $qualification->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
				</table>
				<?php echo $qualifications->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd3/307/11206307/resources/views/print/setup.blade.php ENDPATH**/ ?>